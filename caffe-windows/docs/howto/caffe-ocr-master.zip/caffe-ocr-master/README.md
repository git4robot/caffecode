caffe-ocr
=========

OCR with the [caffe](https://github.com/BVLC/caffe/) deep learning framework

DEPRECATED -> Moved to https://github.com/pannous/tensorflow-ocr

use script to generate more training data, or
get more training data from here:
http://ufldl.stanford.edu/housenumbers/

Also see https://github.com/mateogianolio/mlp-character-recognition for simple js example and 
https://github.com/tmbdev/ocropy for a very comprehensive phython toolchain.
