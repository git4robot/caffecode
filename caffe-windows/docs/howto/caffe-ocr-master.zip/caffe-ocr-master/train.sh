caffe train -solver alpha_solver.prototxt -gpu 0
# takes 20 minutes
# I1112 15:58:39.368252  3465 solver.cpp:246] Iteration 1300, loss = 0.00338976
