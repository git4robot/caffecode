# caffe_test
Using Caffe for Chinese Character Recognition,Number and  Special Character(./%()...etc) with pre-trained caffe model.
用训练好的caffe网络模型进行数字，少量汉字，特殊字符（./等）的识别（总共有210类）
